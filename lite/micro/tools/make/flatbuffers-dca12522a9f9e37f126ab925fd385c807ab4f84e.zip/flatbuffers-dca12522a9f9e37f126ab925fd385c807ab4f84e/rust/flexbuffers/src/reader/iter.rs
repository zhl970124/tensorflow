// Copyright 2019 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

use super::{Reader, VectorReader};
use std::iter::{DoubleEndedIterator, ExactSizeIterator, FusedIterator, Iterator};

/// Iterates over a flexbuffer vector, typed vector, or map. Yields [Readers](struct.Reader.html).
///
/// If any error occurs, the Reader is defaulted to a Null flexbuffer Reader.
pub struct ReaderIterator<'de> {
    pub(super) reader: VectorReader<'de>,
    pub(super) front: usize,
    end: usize,
}
impl<'de> ReaderIterator<'de> {
    pub(super) fn new(reader: VectorReader<'de>) -> Self {
        let end = reader.len();
        ReaderIterator {
            reader,
            front: 0,
            end,
        }
    }
}
impl<'de> Iterator for ReaderIterator<'de> {
    type Item = Reader<'de>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.front < self.end {
            let r = self.reader.idx(self.front);
            self.front += 1;
            Some(r)
        } else {
            None
        }
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        let remaining = self.end - self.front;
        (remaining, Some(remaining))
    }
}
impl<'de> DoubleEndedIterator for ReaderIterator<'de> {
    fn next_back(&mut self) -> Option<Self::Item> {
        if self.front < self.end {
            self.end -= 1;
            Some(self.reader.idx(self.end))
        } else {
            None
        }
    }
}
impl<'de> ExactSizeIterator for ReaderIterator<'de> {}
impl<'de> FusedIterator for ReaderIterator<'de> {}
